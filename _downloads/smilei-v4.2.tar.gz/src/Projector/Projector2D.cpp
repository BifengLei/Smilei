#include "Projector2D.h"

#include "Params.h"
#include "Patch.h"

Projector2D::Projector2D( Params &params, Patch *patch )
    : Projector( params, patch )
{
}

