#ifdef codeConstant_h
#define codeConstant_h

//! \todo{define PI and other constants here}

#endif
